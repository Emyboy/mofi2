const Constants = {
    tablet_width: 755,
}


export default Constants